#!/usr/bin/env python3
"""スキル（AI社員）のフォルダを、claude.ai にアップロードできる zip にする。

先に check_skill.py と同じ検査を通し、不合格なら zip を作らない。
zip の中身は「name のフォルダ/SKILL.md …」の形（claude.ai の Skills にそのまま上げられる形）。
試しの作業フォルダ（evals/・evaluation/・名前が -workspace で終わるもの）とキャッシュは入れない。

使い方:
  python3 make_zip.py スキルのフォルダ
  python3 make_zip.py スキルのフォルダ --out 保存先フォルダ
  python3 make_zip.py スキルのフォルダ --generic   （4点セットの形でないスキル）

終了コード: 0=作成 / 1=検査で不合格・作成失敗 / 2=使い方の誤り

出典: Anthropic skill-creator（Apache-2.0）の scripts/package_skill.py を参考に、
日本語の表示・検査の必須化・作成後の中身確認を足して書き直した。
"""
import argparse
import fnmatch
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from check_skill import check  # noqa: E402

EXCLUDE_DIRS = {"__pycache__", ".git", "node_modules", ".venv"}
ROOT_EXCLUDE_DIRS = {"evals", "evaluation"}
EXCLUDE_FILES = {".DS_Store", "Thumbs.db"}
EXCLUDE_GLOBS = ["*.pyc", "*-workspace"]


def excluded(rel):
    parts = rel.parts
    if set(parts) & EXCLUDE_DIRS:
        return True
    if parts and parts[0] in ROOT_EXCLUDE_DIRS:
        return True
    if any(fnmatch.fnmatch(p, g) for p in parts for g in EXCLUDE_GLOBS):
        return True
    return rel.name in EXCLUDE_FILES


def main():
    ap = argparse.ArgumentParser(description="検査に通ったスキルを claude.ai 用の zip にする")
    ap.add_argument("skill_dir", help="SKILL.md が入っているフォルダ")
    ap.add_argument("--out", default=".", help="zip の保存先フォルダ（既定: 今いるフォルダ）")
    ap.add_argument("--generic", action="store_true", help="4点セットと雛形の書きかけを検査しない")
    a = ap.parse_args()

    root = Path(a.skill_dir).expanduser().resolve()
    res = check(root, a.generic)
    for m in res["warn"]:
        print(f"[注意] {m}")
    if res["ng"]:
        for m in res["ng"]:
            print(f"[NG]   {m}")
        print("結果: 検査で不合格のため zip を作りませんでした。上の NG を直してから、もう一度実行してください")
        return 1
    name = res.get("name") or root.name
    out_dir = Path(a.out).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    zpath = out_dir / f"{name}.zip"
    if root in zpath.parents:
        print("[NG]   zip をスキルのフォルダの中に作ろうとしています。--out で外のフォルダを指定してください")
        return 1

    files = [p for p in sorted(root.rglob("*")) if p.is_file() and not excluded(p.relative_to(root))]
    tmp = zpath.with_suffix(".zip.part")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, f"{name}/{p.relative_to(root).as_posix()}")
    tmp.replace(zpath)

    with zipfile.ZipFile(zpath) as z:
        bad = z.testzip()
        names = z.namelist()
    if bad or f"{name}/SKILL.md" not in names:
        print(f"[NG]   zip の中身を確かめられませんでした（壊れたファイル: {bad}）")
        return 1
    print(f"[OK]   {len(names)} ファイルを入れました（先頭のフォルダ名: {name}/）")
    for n in names:
        print(f"       {n}")
    print(f"結果: 作成しました → {zpath}（{zpath.stat().st_size // 1024 + 1} KB）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
