#!/usr/bin/env python3
"""スキル（AI社員）のフォルダを検査する。claude.ai へのアップロード前・zip 化の前に使う。

検査すること:
  - SKILL.md の先頭（frontmatter）の欄が、許可された欄だけか
    （name / description / license / allowed-tools / metadata / compatibility）
  - name: 半角の英小文字・数字・ハイフンだけ、64字以内
  - description: 1024字以内、山括弧なし、頼み方の例が入っているか
  - 本文の行数（500行を超えたら注意）
  - 本文から参照しているファイル（references/・scripts/・assets/）が実在するか
  - 秘密情報らしき文字列（APIキー・秘密鍵など）が無いか
  - AI社員の4点セット（knowledge.md・reference.md・good-output.md）がそろっているか
  - 雛形の書きかけ（日本語入りの山括弧）が残っていないか
    ※最後の2つは --generic で外せる（4点セットの形ではないスキルを検査するとき）

使い方:
  python3 check_skill.py スキルのフォルダ
  python3 check_skill.py スキルのフォルダ --generic
  python3 check_skill.py スキルのフォルダ --json

終了コード: 0=合格（注意はあってもよい） / 1=不合格 / 2=使い方の誤り

出典: Anthropic skill-creator（Apache-2.0）の scripts/quick_validate.py の検査項目を参考に、
日本語の表示・4点セット・参照先・秘密情報・書きかけの検査を足して書き直した。PyYAML は使わない。
"""
import argparse
import json
import re
import sys
from pathlib import Path

ALLOWED_KEYS = {"name", "description", "license", "allowed-tools", "metadata", "compatibility"}
FOUR_SET = ["references/knowledge.md", "references/reference.md", "references/good-output.md"]
TEXT_SUFFIXES = {".md", ".txt", ".py", ".json", ".yaml", ".yml", ".sh", ".html", ".css", ".js", ".csv"}
SKIP_DIRS = {"__pycache__", ".git", "node_modules"}
SECRET_PATTERNS = [
    ("APIキー（sk-で始まる）", re.compile(r"\bsk-[A-Za-z0-9_\-]{20,}")),
    ("AWSのアクセスキー", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("Googleのキー", re.compile(r"\bAIza[0-9A-Za-z_\-]{30,}")),
    ("GitHubのトークン", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}")),
    ("Slackのトークン", re.compile(r"\bxox[abpr]-[A-Za-z0-9\-]{10,}")),
    ("秘密鍵", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("パスワード・キーの直書き", re.compile(r"(?i)\b(password|passwd|api[_-]?key|secret|token)\s*[:=]\s*[\"'][^\"'\s]{12,}[\"']")),
]
# 本文中のファイル参照（バッククォート内）。山括弧を含むもの＝雛形の説明なので見ない
REF_RE = re.compile(r"`((?:references|scripts|assets)/[^`\s]+)`")
PLACEHOLDER_RE = re.compile(r"<[^<>\n]*[ぁ-んァ-ヶ一-龠々][^<>\n]*>|<\.\.\.>")
UNDECIDED_RE = re.compile(r"（未定・本人に確認）")


def parse_frontmatter(text):
    """先頭の --- から --- までを読み、(欄の辞書, 本文, エラー) を返す。
    入れ子（metadata の下など）は値を文字列のまま持つだけで、中身は見ない。"""
    if not text.startswith("---"):
        return None, text, "SKILL.md の1行目が --- で始まっていません（先頭の欄が無い）"
    lines = text.split("\n")
    end = None
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            end = i
            break
    if end is None:
        return None, text, "先頭の欄を閉じる --- が見つかりません"
    fm = {}
    key = None
    block = None  # 複数行の値（| や >）を集めている欄
    for raw in lines[1:end]:
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if raw[0] in " \t":
            if key is None:
                return None, text, f"先頭の欄の書き方が崩れています: {raw.strip()[:40]}"
            if block is not None:
                fm[key] = (fm[key] + "\n" + raw.strip()).strip()
            else:
                fm[key] = (fm[key] + "\n" + raw).strip("\n")
            continue
        m = re.match(r"^([A-Za-z0-9_\-]+)\s*:\s*(.*)$", raw)
        if not m:
            return None, text, f"先頭の欄の書き方が崩れています: {raw.strip()[:40]}"
        key, val = m.group(1), m.group(2).strip()
        block = None
        if val in ("|", ">", "|-", ">-", "|+", ">+"):
            block = val
            val = ""
        elif len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
            if m.group(2).strip().startswith('"'):
                val = val.replace('\\"', '"')
        fm[key] = val
    body = "\n".join(lines[end + 1:])
    return fm, body, None


def strip_code_blocks(text):
    out, inside = [], False
    for line in text.split("\n"):
        if line.lstrip().startswith("```") or line.lstrip().startswith("~~~"):
            inside = not inside
            continue
        if not inside:
            out.append(line)
    return "\n".join(out)


def iter_text_files(root):
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.suffix.lower() in TEXT_SUFFIXES and not (set(p.relative_to(root).parts) & SKIP_DIRS):
            yield p


def check(skill_dir, generic=False):
    """結果を {"ng": [...], "warn": [...], "ok": [...]} で返す。"""
    root = Path(skill_dir).expanduser().resolve()
    res = {"skill_dir": str(root), "ng": [], "warn": [], "ok": []}
    ng, warn, ok = res["ng"].append, res["warn"].append, res["ok"].append
    md = root / "SKILL.md"
    if not root.is_dir():
        ng(f"フォルダがありません: {root}")
        return res
    if not md.exists():
        ng("SKILL.md がありません（ファイル名は大文字で SKILL.md）")
        return res
    text = md.read_text(encoding="utf-8")
    fm, body, err = parse_frontmatter(text)
    if err:
        ng(err)
        return res

    extra = sorted(set(fm) - ALLOWED_KEYS)
    if extra:
        ng(f"許可されていない欄があります: {', '.join(extra)}（使えるのは {', '.join(sorted(ALLOWED_KEYS))}。"
           f"版を書きたいときは metadata: の下に version: を置く）")
    else:
        ok("先頭の欄は許可された欄だけ")

    name = (fm.get("name") or "").strip()
    res["name"] = name
    if not name:
        ng("name がありません")
    elif not re.match(r"^[a-z0-9-]+$", name):
        ng(f"name「{name}」は半角の英小文字・数字・ハイフンだけにしてください（例 thanks-mail）")
    elif name.startswith("-") or name.endswith("-") or "--" in name:
        ng(f"name「{name}」はハイフンで始めたり終えたり、2つ続けたりできません")
    elif len(name) > 64:
        ng(f"name が長すぎます（{len(name)}字。64字まで）")
    else:
        ok(f"name「{name}」")
        if name != root.name:
            warn(f"フォルダ名「{root.name}」と name「{name}」が違います（そろえると迷いません。zip は name で作ります）")

    desc = (fm.get("description") or "").strip()
    if not desc:
        ng("description がありません（いつ使うスキルかを書く欄。呼び出されるかはここで決まります）")
    else:
        if "<" in desc or ">" in desc:
            ng("description に山括弧（< または >）が入っています。claude.ai のアップロードで弾かれます")
        if len(desc) > 1024:
            ng(f"description が長すぎます（{len(desc)}字。1024字まで）")
        if not ("<" in desc or ">" in desc or len(desc) > 1024):
            ok(f"description（{len(desc)}字）")
        n_examples = len(re.findall(r"「[^」]+」", desc))
        if n_examples < 3:
            warn(f"description の頼み方の例が {n_examples} 個です。「」で囲んだ言い回しを5つ以上入れると呼ばれやすくなります")
        if len(desc) < 60:
            warn("description が短めです。何をするか＋いつ使うかの両方を書きます")

    body_lines = body.strip("\n").count("\n") + 1 if body.strip() else 0
    if body_lines == 0:
        ng("SKILL.md の本文が空です")
    elif body_lines > 500:
        warn(f"本文が {body_lines} 行あります（500行以内が目安。長い型・例は references/ に分ける）")
    else:
        ok(f"本文 {body_lines} 行")

    missing = []
    for ref in sorted(set(REF_RE.findall(strip_code_blocks(body)))):
        if "<" in ref or "*" in ref:
            continue
        ref = ref.rstrip(".,、。）)")
        if not (root / ref).exists():
            missing.append(ref)
    if missing:
        ng("本文で参照しているのに無いファイル: " + ", ".join(missing))
    else:
        ok("本文の参照先はすべて実在")

    secret_hits = []
    for p in iter_text_files(root):
        rel = p.relative_to(root).as_posix()
        for i, line in enumerate(p.read_text(encoding="utf-8", errors="ignore").split("\n"), 1):
            for label, pat in SECRET_PATTERNS:
                if pat.search(line):
                    secret_hits.append(f"{rel}:{i}（{label}）")
    if secret_hits:
        ng("秘密情報らしき文字列: " + ", ".join(secret_hits[:10]) + (" ほか" if len(secret_hits) > 10 else "")
           + "。スキルの外（各自の設定や環境変数）に置いてください")
    else:
        ok("秘密情報らしき文字列なし")

    if not generic:
        lack = [f for f in FOUR_SET if not (root / f).exists()]
        if lack:
            ng("AI社員の4点セットが欠けています: " + ", ".join(lack)
               + "（4点セットの形でないスキルなら --generic を付ける）")
        else:
            ok("4点セット（SKILL.md・knowledge.md・reference.md・good-output.md）がそろっている")
        ph, und = [], []
        for p in iter_text_files(root):
            if p.suffix.lower() != ".md":
                continue
            rel = p.relative_to(root).as_posix()
            for i, line in enumerate(p.read_text(encoding="utf-8", errors="ignore").split("\n"), 1):
                if PLACEHOLDER_RE.search(line):
                    ph.append(f"{rel}:{i}")
                if UNDECIDED_RE.search(line):
                    und.append(f"{rel}:{i}")
        if ph:
            ng("雛形の書きかけ（山括弧）が残っています: " + ", ".join(ph[:10]) + (" ほか" if len(ph) > 10 else ""))
        else:
            ok("雛形の書きかけなし")
        if und:
            warn("「（未定・本人に確認）」が残っています: " + ", ".join(und[:10]) + "（本人に聞いて埋める）")
    return res


def main():
    ap = argparse.ArgumentParser(description="スキル（AI社員）のフォルダを検査する。不合格なら終了コード1")
    ap.add_argument("skill_dir", help="SKILL.md が入っているフォルダ")
    ap.add_argument("--generic", action="store_true", help="4点セットと雛形の書きかけを検査しない（一般のスキル向け）")
    ap.add_argument("--json", action="store_true", help="結果を JSON で出す")
    a = ap.parse_args()
    res = check(a.skill_dir, a.generic)
    res["passed"] = not res["ng"]
    if a.json:
        print(json.dumps(res, ensure_ascii=False, indent=2))
    else:
        for m in res["ok"]:
            print(f"[OK]   {m}")
        for m in res["warn"]:
            print(f"[注意] {m}")
        for m in res["ng"]:
            print(f"[NG]   {m}")
        print(f"結果: {'合格' if res['passed'] else '不合格'}（NG {len(res['ng'])} 件・注意 {len(res['warn'])} 件）")
    return 0 if res["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
