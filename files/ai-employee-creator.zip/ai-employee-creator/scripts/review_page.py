#!/usr/bin/env python3
"""試した結果（スキルあり／なし）を、ブラウザで見比べられる HTML 1枚にまとめる。

読む形（作業フォルダの1周分）:
  <name>-workspace/
  ├── tests.json                     ← テスト一覧（無くてもよい）
  └── iteration-1/                   ← この場所を渡す
      └── <テスト名>/
          ├── prompt.txt             ← 依頼文（tests.json にあれば不要）
          ├── with_skill/
          │   ├── outputs/           ← 出てきた物（.md .txt .json .py .html など）
          │   └── grading.json       ← 採点（無くてもよい）
          ├── without_skill/         ← 同じ形
          └── comparison.json        ← どちらが良いか隠して比べた結果（無くてもよい）

tests.json の形:
  {"skill_name": "thanks-mail",
   "tests": [{"id": 1, "name": "basic", "prompt": "依頼文", "expected": "期待すること", "checks": ["合格条件"]}]}
grading.json の形:
  {"results": [{"check": "合格条件", "passed": true, "evidence": "根拠の引用"}],
   "weak_checks": ["どの出力でも通ってしまう条件"], "notes": "気づいたこと"}
comparison.json の形:
  {"winner": "with_skill", "reason": "理由", "scores": {"with_skill": 8, "without_skill": 5}}

使い方:
  python3 review_page.py 作業フォルダ/iteration-1
  python3 review_page.py 作業フォルダ/iteration-1 --out review.html --title "お礼メール 1周目"

HTML は外部の読み込みなしで開けます。感想欄に書いた内容は「感想をまとめてコピー」で
文章にしてコピーできるので、そのままチャットに貼って返してください。
"""
import argparse
import html
import json
import sys
from pathlib import Path

TEXT_SUFFIXES = {".md", ".txt", ".json", ".py", ".html", ".csv", ".yaml", ".yml", ".js", ".css", ".sh"}
MAX_CHARS = 20000
CONFIG_ORDER = ["with_skill", "old_skill", "without_skill"]
CONFIG_LABEL = {"with_skill": "スキルあり", "without_skill": "スキルなし", "old_skill": "前の版"}


def load_json(p):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def find_tests_json(it_dir):
    for p in (it_dir / "tests.json", it_dir.parent / "tests.json"):
        if p.exists():
            data = load_json(p) or {}
            return {str(t.get("name") or t.get("id")): t for t in data.get("tests", [])}, data.get("skill_name", "")
    return {}, ""


def read_outputs(cfg_dir):
    out_dir = cfg_dir / "outputs"
    base = out_dir if out_dir.is_dir() else cfg_dir
    items = []
    for p in sorted(base.rglob("*")):
        if not p.is_file() or p.name in ("grading.json", "timing.json") or p.suffix.lower() not in TEXT_SUFFIXES:
            if p.is_file() and p.suffix.lower() not in TEXT_SUFFIXES:
                items.append((p.relative_to(base).as_posix(), f"（文字ではないファイル: {p.stat().st_size // 1024 + 1} KB）"))
            continue
        t = p.read_text(encoding="utf-8", errors="replace")
        if len(t) > MAX_CHARS:
            t = t[:MAX_CHARS] + f"\n…（長いので {MAX_CHARS} 字で切りました）"
        items.append((p.relative_to(base).as_posix(), t))
    return items


def config_dirs(test_dir):
    dirs = [d for d in test_dir.iterdir() if d.is_dir() and not d.name.startswith((".", "_"))]
    return sorted(dirs, key=lambda d: (CONFIG_ORDER.index(d.name) if d.name in CONFIG_ORDER else 9, d.name))


def esc(s):
    return html.escape(str(s), quote=True)


def build(it_dir, title):
    tests, skill_name = find_tests_json(it_dir)
    test_dirs = sorted(d for d in it_dir.iterdir() if d.is_dir() and not d.name.startswith((".", "_")))
    summary = {}
    sections = []
    for ti, td in enumerate(test_dirs, 1):
        meta = tests.get(td.name, {})
        prompt = meta.get("prompt") or ((td / "prompt.txt").read_text(encoding="utf-8").strip() if (td / "prompt.txt").exists() else "（依頼文の記録なし）")
        cols = []
        for cd in config_dirs(td):
            label = CONFIG_LABEL.get(cd.name, cd.name)
            g = load_json(cd / "grading.json") or {}
            results = g.get("results", [])
            passed = sum(1 for r in results if r.get("passed"))
            s = summary.setdefault(label, [0, 0])
            s[0] += passed
            s[1] += len(results)
            rows = "".join(
                f'<li class="{"pass" if r.get("passed") else "fail"}"><b>{"合格" if r.get("passed") else "不合格"}</b> '
                f'{esc(r.get("check", ""))}<div class="ev">{esc(r.get("evidence", ""))}</div></li>' for r in results)
            weak = "".join(f"<li>{esc(w)}</li>" for w in g.get("weak_checks", []))
            grade_html = (f'<p class="score">合格条件 {passed}/{len(results)}</p><ul class="grades">{rows}</ul>' if results else '<p class="muted">採点なし</p>')
            if weak:
                grade_html += f'<details><summary>弱い条件（どの出力でも通る）</summary><ul>{weak}</ul></details>'
            if g.get("notes"):
                grade_html += f'<p class="muted">{esc(g["notes"])}</p>'
            outs = "".join(f'<details open><summary>{esc(n)}</summary><pre>{esc(t)}</pre></details>' for n, t in read_outputs(cd)) or '<p class="muted">出力なし</p>'
            cols.append(f'<div class="col"><h4>{esc(label)}</h4>{grade_html}<div class="outs">{outs}</div></div>')
        comp = load_json(td / "comparison.json")
        comp_html = ""
        if comp:
            w = CONFIG_LABEL.get(comp.get("winner", ""), comp.get("winner", ""))
            comp_html = f'<p class="comp">隠して比べた結果: <b>{esc(w)}</b> — {esc(comp.get("reason", ""))}</p>'
        checks = "".join(f"<li>{esc(c)}</li>" for c in meta.get("checks", []))
        sections.append(f'''<section class="test" data-name="{esc(td.name)}">
<h3>{ti}. {esc(td.name)}</h3>
<div class="prompt"><b>依頼文</b><pre>{esc(prompt)}</pre>{f"<b>合格条件</b><ul>{checks}</ul>" if checks else ""}</div>
{comp_html}<div class="cols">{"".join(cols)}</div>
<label class="fb">感想（直してほしい所。良ければ空のまま）<textarea rows="3"></textarea></label>
</section>''')
    sum_rows = "".join(f"<tr><td>{esc(k)}</td><td>{v[0]}/{v[1]}</td><td>{(v[0] * 100 // v[1]) if v[1] else '-'}%</td></tr>" for k, v in summary.items())
    head_title = title or f"{skill_name or it_dir.parent.name} {it_dir.name} の結果"
    js_title = json.dumps(head_title, ensure_ascii=False).replace("</", "<\\/")
    return f'''<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(head_title)}</title>
<style>
:root{{--bg:#fafaf8;--fg:#1d1d1f;--muted:#6b6b70;--card:#fff;--line:#e3e3e0;--ok:#1f7a4d;--ng:#b3261e;--accent:#2b59c3}}
@media (prefers-color-scheme:dark){{:root{{--bg:#16161a;--fg:#ececf0;--muted:#a0a0a8;--card:#202026;--line:#34343c;--ok:#5fcf95;--ng:#ff8a80;--accent:#8fb0ff}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--fg);font:15px/1.7 -apple-system,"Hiragino Sans","Noto Sans JP",sans-serif}}
main{{max-width:1180px;margin:0 auto;padding:16px}}h1{{font-size:20px;margin:8px 0}}h3{{margin:0 0 8px}}h4{{margin:0 0 6px}}
table{{border-collapse:collapse;margin:8px 0 16px}}td,th{{border:1px solid var(--line);padding:4px 10px}}
.test{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px;margin:14px 0}}
.prompt pre,.outs pre{{white-space:pre-wrap;word-break:break-word;background:var(--bg);border:1px solid var(--line);border-radius:6px;padding:8px;margin:4px 0;font-size:13px;max-height:420px;overflow:auto}}
.cols{{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;margin-top:10px}}
.col{{border:1px solid var(--line);border-radius:8px;padding:10px;min-width:0}}
.grades{{padding-left:18px;margin:4px 0}}.pass b{{color:var(--ok)}}.fail b{{color:var(--ng)}}.ev{{color:var(--muted);font-size:13px}}
.score{{font-weight:700;margin:0}}.muted{{color:var(--muted)}}.comp{{border-left:3px solid var(--accent);padding-left:8px}}
.fb{{display:block;margin-top:10px}}textarea{{width:100%;font:inherit;padding:6px;border:1px solid var(--line);border-radius:6px;background:var(--bg);color:var(--fg)}}
button{{font:inherit;padding:8px 14px;border-radius:8px;border:1px solid var(--accent);background:var(--accent);color:#fff;cursor:pointer}}
summary{{cursor:pointer}}
</style></head><body><main>
<h1>{esc(head_title)}</h1>
<p class="muted">テストごとに「依頼文 → スキルあり／なしの出力と採点」を並べています。気になった所を感想欄に書き、最後にまとめてコピーしてチャットに貼ってください。</p>
<table><tr><th>種類</th><th>合格条件</th><th>通過率</th></tr>{sum_rows or "<tr><td colspan=3>採点なし</td></tr>"}</table>
{"".join(sections) or "<p>テストのフォルダが見つかりませんでした。</p>"}
<p><button id="copy">感想をまとめてコピー</button> <span id="done" class="muted"></span></p>
<pre id="fbout" hidden></pre>
<script>
document.getElementById("copy").onclick=function(){{
  var lines=["【感想】"+{js_title}];
  document.querySelectorAll(".test").forEach(function(s){{
    var t=s.querySelector("textarea").value.trim();
    lines.push("- "+s.dataset.name+": "+(t||"問題なし"));
  }});
  var text=lines.join("\\n"),out=document.getElementById("fbout");
  out.textContent=text;out.hidden=false;
  if(navigator.clipboard){{navigator.clipboard.writeText(text).then(function(){{document.getElementById("done").textContent="コピーしました。チャットに貼ってください";}},function(){{document.getElementById("done").textContent="下の文章を選んでコピーしてください";}});}}
  else{{document.getElementById("done").textContent="下の文章を選んでコピーしてください";}}
}};
</script></main></body></html>'''


def main():
    ap = argparse.ArgumentParser(description="試した結果（スキルあり／なし・採点）を HTML 1枚にまとめる")
    ap.add_argument("iteration_dir", help="作業フォルダの1周分（例: thanks-mail-workspace/iteration-1）")
    ap.add_argument("--out", help="保存先の HTML（既定: 1周分のフォルダの中の review.html）")
    ap.add_argument("--title", default="", help="ページの題名")
    a = ap.parse_args()
    it = Path(a.iteration_dir).expanduser().resolve()
    if not it.is_dir():
        print(f"[NG] フォルダがありません: {it}")
        return 2
    out = Path(a.out).expanduser().resolve() if a.out else it / "review.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(build(it, a.title), encoding="utf-8")
    print(f"結果: 作成しました → {out}")
    print("ブラウザで開いて確認してください（Mac: open、Windows: start、それ以外: ファイルをダブルクリック）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
