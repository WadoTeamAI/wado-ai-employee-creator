#!/usr/bin/env python3
"""発動テスト: スキルの説明（description）で、呼ばれるべき依頼で呼ばれ、呼ばれるべきでない依頼で呼ばれないかを測る。

Claude Code 専用（claude コマンドを使う。claude.ai では使えません）。
一時フォルダにスキルの写しを「別名」で置き、その中で claude -p を依頼ごとに実行して、
その写しが呼ばれたか（Skill の呼び出し、または SKILL.md の読み込み）を見ます。
あなたのプロジェクトや ~/.claude には何も書き込みません。

依頼の一覧（JSON）の形:
  [{"query": "依頼文", "should_trigger": true},
   {"query": "似ているが別の依頼", "should_trigger": false}]

使い方:
  python3 trigger_test.py --skill スキルのフォルダ --queries queries.json --dry-run
  python3 trigger_test.py --skill スキルのフォルダ --queries queries.json --runs 3 --out result.json
  python3 trigger_test.py --skill スキルのフォルダ --queries queries.json --split   （学習用60%／確認用40%に分けて表示）
  python3 trigger_test.py --skill スキルのフォルダ --queries queries.json --description "試したい説明文"

注意:
  - 1回の実行ごとに Claude Code の利用枠を使います（依頼の数 × --runs 回）。--dry-run で回数を先に確かめてください
  - 環境変数 ANTHROPIC_API_KEY があると従量課金になるため、既定では外してログイン中のプランで実行します（--use-api-key で API キーを使う）
  - 同じ名前のスキルを ~/.claude/skills に入れていると、そちらが先に呼ばれて「呼ばれなかった」と数えることがあります
  - 呼ばれ方には揺れがあります。1つの依頼を3回ずつ回し、半分以上で呼ばれたら「呼ばれた」とします

終了コード: 0=実行できた（正答率は結果を見る） / 1=実行できなかった / 2=使い方の誤り

出典: Anthropic skill-creator（Apache-2.0）の scripts/run_eval.py の検出方法
（claude -p の stream-json で Skill／Read の呼び出しを読む）を参考にした。
変更点: スキルを一時フォルダに別名で置く（利用者のプロジェクトを書き換えない）／select を使わず
Windows でも動く読み方にした／ToolSearch などの下準備の道具は無視する／学習用・確認用の分割と日本語の表示を足した。
"""
import argparse
import json
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

IGNORE_TOOLS = {"ToolSearch", "TodoWrite", "TaskCreate", "TaskUpdate"}


def read_description(skill_dir):
    text = (skill_dir / "SKILL.md").read_text(encoding="utf-8")
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from check_skill import parse_frontmatter
    fm, _body, err = parse_frontmatter(text)
    if err:
        raise SystemExit(f"[NG] SKILL.md の先頭を読めません: {err}")
    return fm.get("name", skill_dir.name), fm.get("description", "")


def stage_skill(skill_dir, test_name, description):
    """一時フォルダの中のスキル置き場（.claude の下の skills/<test_name>/）にスキルの写しを置き、name と description を差し替える。"""
    work = Path(tempfile.mkdtemp(prefix="trigger_test_"))
    dst = work / ".claude" / "skills" / test_name
    shutil.copytree(skill_dir, dst, ignore=shutil.ignore_patterns("*-workspace", "evals", "evaluation", "__pycache__", ".git"))
    md = dst / "SKILL.md"
    text = md.read_text(encoding="utf-8")
    end = text.index("\n---", 3)
    head, rest = text[:end], text[end:]
    head = re.sub(r"(?m)^name:.*$", f"name: {test_name}", head)
    desc_line = "description: " + json.dumps(description, ensure_ascii=False)
    # description が複数行（| や >）でも1行に置き換える
    head = re.sub(r"(?ms)^description:.*?(?=^[A-Za-z0-9_\-]+\s*:|\Z)", desc_line + "\n", head).rstrip("\n")
    md.write_text(head + rest, encoding="utf-8")
    return work


def run_once(query, test_name, work, timeout, model, use_api_key):
    """1回実行し、(呼ばれたか, エラーの説明 または None) を返す。"""
    cmd = ["claude", "-p", query, "--output-format", "stream-json", "--verbose", "--include-partial-messages"]
    if model:
        cmd += ["--model", model]
    drop = {"CLAUDECODE"} if use_api_key else {"CLAUDECODE", "ANTHROPIC_API_KEY"}
    env = {k: v for k, v in os.environ.items() if k not in drop}
    try:
        proc = subprocess.Popen(cmd, cwd=str(work), env=env, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                stdin=subprocess.DEVNULL, text=True, encoding="utf-8", errors="replace")
    except FileNotFoundError:
        raise SystemExit("[NG] claude コマンドが見つかりません（Claude Code を入れてから実行してください）")
    timer = threading.Timer(timeout, proc.kill)
    timer.start()
    result = None
    error = None
    started = False
    pending, acc = None, ""
    try:
        for line in proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except ValueError:
                continue
            t = ev.get("type")
            if t == "system" and ev.get("subtype") == "init":
                started = True
            if t == "stream_event":
                se = ev.get("event", {})
                st = se.get("type", "")
                if st == "content_block_start":
                    cb = se.get("content_block", {})
                    if cb.get("type") == "tool_use":
                        name = cb.get("name", "")
                        if name in ("Skill", "Read"):
                            pending, acc = name, ""
                        elif name in IGNORE_TOOLS:
                            pending = None
                        else:
                            result = False
                            break
                elif st == "content_block_delta" and pending:
                    d = se.get("delta", {})
                    if d.get("type") == "input_json_delta":
                        acc += d.get("partial_json", "")
                        if test_name in acc:
                            result = True
                            break
                elif st == "content_block_stop" and pending:
                    if test_name in acc:
                        result = True
                        break
                    pending, acc = None, ""
            elif t == "assistant":
                for c in ev.get("message", {}).get("content", []):
                    if c.get("type") == "tool_use":
                        inp = json.dumps(c.get("input", {}), ensure_ascii=False)
                        if c.get("name") in ("Skill", "Read") and test_name in inp:
                            result = True
                            break
                if result:
                    break
            elif t == "result":
                if ev.get("is_error") or ev.get("subtype") not in (None, "success"):
                    error = str(ev.get("result") or ev.get("subtype") or "不明なエラー")[:120]
                break
    finally:
        timer.cancel()
        if proc.poll() is None:
            proc.kill()
        proc.wait()
    if result is None and error is None and not started:
        error = "claude が起動できませんでした（ログインしているか、claude -p が単体で動くかを確かめてください）"
    return bool(result), (None if result else error)


def split_queries(queries, seed):
    rnd = random.Random(seed)
    train, test = [], []
    for flag in (True, False):
        group = [q for q in queries if bool(q.get("should_trigger")) == flag]
        rnd.shuffle(group)
        k = max(1, round(len(group) * 0.6)) if group else 0
        train += group[:k]
        test += group[k:]
    return train, test


def main():
    ap = argparse.ArgumentParser(description="スキルの説明で、呼ばれるべき依頼に呼ばれるかを測る（Claude Code 専用）")
    ap.add_argument("--skill", required=True, help="SKILL.md が入っているフォルダ")
    ap.add_argument("--queries", required=True, help="依頼の一覧（JSON）")
    ap.add_argument("--description", help="SKILL.md の代わりに試す説明文（SKILL.md は書き換えない）")
    ap.add_argument("--runs", type=int, default=3, help="1つの依頼を何回回すか（既定 3）")
    ap.add_argument("--workers", type=int, default=4, help="同時に回す数（既定 4）")
    ap.add_argument("--timeout", type=int, default=90, help="1回の上限秒数（既定 90）")
    ap.add_argument("--threshold", type=float, default=0.5, help="この割合以上で呼ばれたら「呼ばれた」（既定 0.5）")
    ap.add_argument("--model", help="使うモデル（省略時は Claude Code の既定）")
    ap.add_argument("--split", action="store_true", help="学習用60%%／確認用40%%に分けて正答率を出す")
    ap.add_argument("--seed", type=int, default=42, help="分け方の乱数の種（既定 42）")
    ap.add_argument("--out", help="結果の保存先（JSON）")
    ap.add_argument("--use-api-key", action="store_true",
                    help="環境変数 ANTHROPIC_API_KEY を使って実行する（従量課金）。既定では外して、ログイン中のプランで実行する")
    ap.add_argument("--dry-run", action="store_true", help="実行せず、回数と依頼の一覧だけ表示する")
    a = ap.parse_args()

    skill = Path(a.skill).expanduser().resolve()
    if not (skill / "SKILL.md").exists():
        print(f"[NG] SKILL.md がありません: {skill}")
        return 2
    try:
        queries = json.loads(Path(a.queries).expanduser().read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        print(f"[NG] 依頼の一覧を読めません: {e}")
        return 2
    if not isinstance(queries, list) or not all(isinstance(q, dict) and "query" in q for q in queries):
        print('[NG] 依頼の一覧は [{"query": "...", "should_trigger": true}, ...] の形にしてください')
        return 2
    name, desc = read_description(skill)
    if a.description:
        desc = a.description
    if "<" in desc or ">" in desc or len(desc) > 1024:
        print("[NG] 説明文に山括弧があるか、1024字を超えています")
        return 2
    train, test = split_queries(queries, a.seed) if a.split else (queries, [])
    total = len(queries) * a.runs
    pos = sum(1 for q in queries if q.get("should_trigger"))
    print(f"スキル: {name} / 依頼 {len(queries)} 本（呼ばれるべき {pos}・呼ばれるべきでない {len(queries) - pos}）× {a.runs} 回 = {total} 回実行")
    if os.environ.get("ANTHROPIC_API_KEY"):
        print("[注意] ANTHROPIC_API_KEY が設定されています。" + ("--use-api-key のため API キーで実行します（従量課金）" if a.use_api_key
              else "外して、ログイン中のプランで実行します（API キーで払うときは --use-api-key）"))
    if (Path.home() / ".claude" / "skills" / name).exists():
        print(f"[注意] ~/.claude/skills/{name} が入っています。そちらが呼ばれると「呼ばれなかった」と数えます")
    if a.dry_run:
        for q in queries:
            mark = "呼ばれるべき" if q.get("should_trigger") else "呼ばれるべきでない"
            part = "確認用" if q in test else "学習用" if a.split else ""
            print(f"  [{mark}]{('[' + part + ']') if part else ''} {q['query'][:70]}")
        print("（dry-run のため実行していません）")
        return 0

    test_name = f"{name[:40]}-t{uuid.uuid4().hex[:6]}"
    work = stage_skill(skill, test_name, desc)
    try:
        jobs = [(i, q["query"]) for i, q in enumerate(queries) for _ in range(a.runs)]
        hits = {i: 0 for i in range(len(queries))}
        errors = []
        done = [0]
        lock = threading.Lock()

        def job(item):
            i, qtext = item
            r, err = run_once(qtext, test_name, work, a.timeout, a.model, a.use_api_key)
            with lock:
                hits[i] += int(r)
                if err:
                    errors.append(err)
                done[0] += 1
                print(f"  {done[0]}/{total} 回目 済み", file=sys.stderr)

        with ThreadPoolExecutor(max_workers=max(1, a.workers)) as ex:
            list(ex.map(job, jobs))
    finally:
        shutil.rmtree(work, ignore_errors=True)

    if errors:
        print(f"[注意] {len(errors)}/{total} 回がエラーで終わりました（例: {errors[0]}）。エラーの回は「呼ばれなかった」と数えています")
        if len(errors) == total:
            print("[NG] すべての回がエラーでした。結果は使えません")
            return 1
    rows = []
    for i, q in enumerate(queries):
        rate = hits[i] / a.runs
        triggered = rate >= a.threshold
        rows.append({"query": q["query"], "should_trigger": bool(q.get("should_trigger")), "trigger_rate": round(rate, 2),
                     "correct": triggered == bool(q.get("should_trigger")),
                     "set": ("test" if q in test else "train") if a.split else "all"})

    def acc(rs):
        return f"{sum(r['correct'] for r in rs)}/{len(rs)}" if rs else "-"

    print("\n結果（○=期待どおり ×=外れ）")
    for r in rows:
        mark = "呼ばれるべき" if r["should_trigger"] else "呼ばれるべきでない"
        print(f"  {'○' if r['correct'] else '×'} [{mark}] 呼ばれた割合 {r['trigger_rate']:.0%}  {r['query'][:60]}")
    if a.split:
        print(f"正答: 学習用 {acc([r for r in rows if r['set'] == 'train'])} / 確認用 {acc([r for r in rows if r['set'] == 'test'])}")
        print("説明文を直すときは学習用の外れだけを見て直し、確認用の正答で良くなったかを判断します")
    print(f"正答: 全体 {acc(rows)}")
    if a.out:
        Path(a.out).expanduser().write_text(json.dumps({"skill": name, "description": desc, "runs": a.runs, "errors": len(errors), "results": rows},
                                                       ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"保存しました → {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
