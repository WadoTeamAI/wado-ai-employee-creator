# AI社員クリエイター（ai-employee-creator）配布版

毎回チャットで説明し直している仕事を日本語で聞き取り、Claude Code・Codex などのAIエージェントで使える Skill（AI社員1人）に仕上げます。
ナレッジ・リファレンス・ワークフロー・正しいアウトプットの4つをそろえたうえで、スキルあり／なしで試して比べ、合格条件で採点し、直し、呼ばれ方を調整し、claude.ai に入れる zip まで一緒に進めます。作ったスキルを直す・試すだけ・zip にするだけ、にも使えます。

## 動作条件

- Claude Code（macOS / Windows / Linux）、Codex、または Skills が使える claude.ai（ブラウザ・アプリ）
- 補助スクリプトは Python 3.9 以上・追加のインストール不要。Claude Code では4本とも、Codex では発動テスト以外の3本を使えます。claude.ai ではコードを実行できる環境のときだけ使い、使えなければ同じ確認を手で行います
- 発動テスト（`scripts/trigger_test.py`）は Claude Code 専用です。1回ごとに利用枠を使います
- 使えるプラン・画面の名前は変わることがあります。公式ヘルプで最新を確認してください

## インストール

Claude Code の場合:

```bash
unzip ai-employee-creator.zip -d ~/.claude/skills/
```

Codex の場合:

```bash
unzip ai-employee-creator.zip -d ~/.codex/skills/
```

claude.ai の場合: 設定画面の Skills から、この zip をそのままアップロードします。

## 1分の動作確認

「AI社員を作りたい。任せたいのはセミナー後のお礼メール」のように話しかけます。AI社員の方から質問が返ってきます。

Claude Code では、検査も試せます。

```bash
python3 ~/.claude/skills/ai-employee-creator/scripts/check_skill.py ~/.claude/skills/ai-employee-creator --generic
```

「結果: 合格」と出れば準備完了です。

## 補助スクリプト

| スクリプト | すること |
|---|---|
| `scripts/check_skill.py` | スキルのフォルダを検査（先頭の欄・名前・説明文・行数・参照先・秘密情報・4点セット・書きかけ） |
| `scripts/make_zip.py` | 検査に通ったスキルを claude.ai 用の zip にする |
| `scripts/review_page.py` | 試した結果（スキルあり／なし・採点）を見比べる HTML 1枚を作る |
| `scripts/trigger_test.py` | 呼ばれるべき依頼で呼ばれるかを測る（Claude Code 専用） |

どれも `--help` で使い方が出ます。

## 困ったとき

| 症状 | 対処 |
|---|---|
| スキルが呼ばれない | Claude Code なら `/ai-employee-creator` と打って直接呼び出す |
| claude.ai でアップロードが弾かれる | `check_skill.py` で検査する。先頭の欄に `version:` などの許可されていない欄があると弾かれます |
| 仕事を2つ頼んだら1つに絞られた | 仕様です。1人のAI社員に任せる仕事は1つ。2つ目は別のAI社員にします |
| 実績や数字を入れてほしい | 自分で渡した事実だけを使います。AIは数字を作りません |
| `trigger_test.py` がすぐ終わる・全部エラー | `claude -p "hi"` が単体で動くか確かめる。環境変数 ANTHROPIC_API_KEY は既定で外して実行します（従量課金を避けるため） |

## 同梱物

| ファイル | 中身 |
|---|---|
| `SKILL.md` | AI社員の手順と判断の基準 |
| `references/interview-sheet.md` | 聞き取りの質問 |
| `references/writing-guide.md` | 説明文・本文の書き方 |
| `references/ai-employee-template.md` | 作るAI社員のファイル雛形 |
| `references/test-and-compare.md` | 試して比べる手順と採点 |
| `references/improve-guide.md` | 直し方と止める条件 |
| `references/trigger-tuning.md` | 呼ばれ方の調整 |
| `references/quality-checklist.md` | 組み立ての検査と、試した結果の確認表 |
| `references/example-output.md` | 完成形の見本（お礼メール担当の例） |
| `output/` | このAI社員を実際に動かして作った成果物（お礼メール担当のAI社員の zip・試した記録） |
| `scripts/` | 補助スクリプト4本 |
| `LICENSE-skill-creator.txt` | Apache License 2.0 の本文 |
| `README.md` | このファイル |

## 出典

手順と原則の一部、および `check_skill.py`・`make_zip.py`・`trigger_test.py` は、Anthropic の skill-creator（Apache License 2.0）を参考に日本語で書き直したものです。ライセンス本文は `LICENSE-skill-creator.txt` にあります。

## 配布範囲

公式LINEに登録した方向けの特典です。再配布はご遠慮ください。※成果には個人差があります。
