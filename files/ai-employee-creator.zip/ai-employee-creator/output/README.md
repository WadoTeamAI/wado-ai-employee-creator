# output/ — AI社員クリエイターを実際に動かして作った成果物

AI社員クリエイターに「AI社員を作りたい。任せたいのはセミナー後のお礼メール」と頼み、最後まで進めた記録です。題材の見本メールと答えは説明用の例で、実在の人・数字は入っていません。

| ファイル | 中身 |
|---|---|
| `zip/seminar-thanks-mail.zip` | できあがったAI社員（SKILL.md と references/ の3ファイル）。`scripts/make_zip.py` で作成・検査合格。展開すると中身を見られ、そのまま claude.ai にも入れられます |
| `seminar-thanks-mail-workspace/tests.json` | 試した依頼3本と合格条件14個 |
| `seminar-thanks-mail-workspace/iteration-1/` | 1周目の「スキルあり／なし」の出力・採点・見比べページ（review.html） |
| `seminar-thanks-mail-workspace/iteration-2/` | 直したあとの2周目 |
| `seminar-thanks-mail-workspace/trigger-queries.json` | 呼ばれるべき依頼・呼ばれるべきでない依頼の例（8本ずつ） |
| `final-report.md` | 最後に返ってきた報告（AIに任せた所／自分で決める所） |

結果（この1回の実行・採点はAIが1人で実施）:
- 合格条件の通過: スキルあり 14/14、スキルなし 8/14
- スキルなしが落としたのは、お礼が最初に無い・要点が長い・締めに次の行動が無い・「必ず」を使った・要点を聞かずに書いた、の5点
- 2周目は1周目から全部通っていたため、通過数は変わっていません
- 呼ばれ方の測定（`scripts/trigger_test.py`）は省きました

自分のAI社員を作るときの見本として、どこに何が入るかを見比べてください。

※ できあがったAI社員を展開したフォルダで置かないのは、このAI社員クリエイターの zip の中に SKILL.md が2つ並ばないようにするためです。
